import { world, system, EntityDamageCause } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';

// Хранилище данных игроков
const playerData = new Map();

// Регистрация кастомных предметов
world.beforeEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;
  
  // Pistol MK1 (используем carrot_on_a_stick как основу)
  if (item.typeId === 'minecraft:carrot_on_a_stick' && item.nameTag === '§6🔫 Pistol MK1') {
    event.cancel = true;
    shootPistol(player, 1);
  }
  
  // Pistol MK2
  if (item.typeId === 'minecraft:carrot_on_a_stick' && item.nameTag === '§c🔫 Pistol MK2') {
    event.cancel = true;
    shootPistol(player, 2);
  }
});

// Основная функция стрельбы
function shootPistol(player, type) {
  const data = playerData.get(player.id) || { ammo: 30, reloading: false };
  
  if (data.reloading) {
    player.sendMessage('§c🔄 Перезарядка...');
    return;
  }
  
  if (data.ammo <= 0) {
    startReload(player);
    return;
  }
  
  // Уменьшаем патроны
  data.ammo--;
  playerData.set(player.id, data);
  
  // Параметры пистолета
  const damage = type === 1 ? 10 : 20;
  const spread = type === 1 ? 0.3 : 0.1;
  const fireRate = type === 1 ? 5 : 20; // тики между выстрелами
  
  // Отдача
  player.applyKnockback(0, 0, 0.2, 0.1);
  
  // Эффекты выстрела
  player.dimension.spawnParticle('minecraft:large_smoke', {
    x: player.location.x,
    y: player.location.y + 1.6,
    z: player.location.z
  });
  
  player.playSound('random.explode', { volume: 0.5, pitch: 2.0 });
  
  // Луч трассировки пули
  const direction = player.getRotation();
  const ray = player.dimension.getBlockFromRay(
    player.location,
    {
      x: Math.sin(direction.y * Math.PI / 180) * Math.cos(direction.x * Math.PI / 180),
      y: -Math.sin(direction.x * Math.PI / 180),
      z: Math.cos(direction.y * Math.PI / 180) * Math.cos(direction.x * Math.PI / 180)
    },
    { maxDistance: 50 }
  );
  
  // Попадание
  if (ray.block) {
    // Стена — эффект попадания
    ray.block.dimension.spawnParticle('minecraft:critical_hit_emitter', ray.block.location);
  } else {
    // Попадание в сущность (добавь логику raycast для мобов)
    const entities = player.dimension.getEntities({
      location: player.location,
      maxDistance: 50,
      type: 'minecraft:zombie' // пример для зомби
    });
    
    if (entities.length > 0) {
      const target = entities[0];
      target.applyDamage(damage);
      player.dimension.spawnParticle('minecraft:damage_indicator_particle', target.location);
    }
  }
  
  // Прицел для MK2
  if (type === 2) {
    showScope(player);
  }
  
  player.sendMessage(`§a💾 ${data.ammo}/30`);
}

// Перезарядка
function startReload(player) {
  const data = playerData.get(player.id) || { ammo: 0, reloading: true };
  data.reloading = true;
  playerData.set(player.id, data);
  
  player.sendMessage('§e🔄 Перезарядка...');
  player.playSound('ui.button.click', { volume: 0.5 });
  
  system.runTimeout(() => {
    data.ammo = 30;
    data.reloading = false;
    playerData.set(player.id, data);
    player.sendMessage('§a✅ Перезаряжено!');
  }, 60); // 3 секунды
}

// Прицел для MK2
function showScope(player) {
  const form = new ActionFormData()
    .title('🔭 Прицел Pistol MK2')
    .body('§l§6ЦЕЛЬ В ПЕРЕКРЕСТИИ\n§r§7Нажми для стрельбы с прицелом')
    .button('§aВыстрелить');
  
  form.show(player).then((response) => {
    if (response.canceled) return;
    // Логика точного выстрела
    player.sendMessage('§6🎯 Точный выстрел!');
  });
}

// Крафт пистолетов (команда для теста)
/world.beforeEvents.chatSend.subscribe((event) => {
  const player = event.sender;
  const message = event.message;
  
  if (message === '/pistol1') {
    event.cancel = true;
    const item = new ItemStack('minecraft:carrot_on_a_stick', 1);
    item.nameTag = '§6🔫 Pistol MK1';
    player.getComponent('minecraft:inventory').container.addItem(item);
    player.sendMessage('§a🔫 Pistol MK1 получен!');
  }
  
  if (message === '/pistol2') {
    event.cancel = true;
    const item = new ItemStack('minecraft:carrot_on_a_stick', 1);
    item.nameTag = '§c🔫 Pistol MK2';
    player.getComponent('minecraft:inventory').container.addItem(item);
    player.sendMessage('§c🔫 Pistol MK2 получен!');
  }
});